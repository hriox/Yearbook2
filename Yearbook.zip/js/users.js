var users =
[
    [
        1,
        'heliorobertoloureirorios.png',
        'Helio Rios',  
        'Belém',
        'Pará',
        -1.385902, 
        -48.45873799999998,
        'A'
    ],
    [
        2,
        'carlospossa.png',
        'Carlos Possa',
        'Natal',
        'Rio Grande do Norte',             
        -5.779264, 
        -35.200911,
        'A'
    ],
    [
        3,
        'paulobrito.png',
        'Paulo Brito', 
        'Porto Alegre',
        'Rio Grande do Sul',
        -30.034419, 
        -51.2116,
        'A'
    ],    
    [
        4,
        'danielagondim.png',
        'Daniela Gondim',
        'Araxá',
        'Minas Gerais',
        -19.5906483, 
        -46.944241199999965,
        'A'
    ],
    [
        5,
        'generic.png',
        'Rodrigo Balthazar',
        'Brasília',
        'Distrito Federal',
        -15.7941454,
        -47.88254789999996,
        'A'
    ],
    [
        6,
        'generic.png',
        'Fabiano Pessoa',
        'Rio de Janeiro',
        'Rio de Janeiro',
        -22.9082998,
        -43.19707729999999,
        'A'
    ],
    [
        7,
        'generic.png',
        'Rafael B. Teixeira',
        'Avaré',
        'São Paulo',
        -23.1072154,
        -48.925516000000016,
        'A'
    ],
    [
        8,
        'generic.png',
        'Fernando Gama',
        'Barra de São Francisco',
        'Espírito Santo',
        -18.7553213,
        -40.89683980000001,
        'A'
    ],
    [
        9,
        'generic.png',
        'Elizangela Silva',
        'Campo Grande',
        'Mato Grosso do Sul',
        -20.4697105,
        -54.620121100000006,
        'A'
    ],
    [
        10,
        'generic.png',
        'Frederico Moraes',
        'Sete Lagoas',
        'Minas Gerais',
        -19.45738,
        -44.2416695,
        'A'
    ],
    [
        11,
        'generic.png',
        'Paulo Candido',
        'São Gotardo',
        'Minas Gerais',
        -19.3092,
        -46.046904100000006,
        'A'
    ],
    [
        12,
        'generic.png',
        'Fernanda Carvalho',
        'Machado',
        'Minas Gerais',
        -21.6782422,
        -45.92228979999999,
        'A'
    ],
    [
        13,
        'generic.png',
        'Leonardo Antonio',
        'Nova Serrana',
        'Minas Gerais',
        -19.8717775,
        -44.98508279999999,
        'A'
    ],
    [
        14,
        'generic.png',
        'Daniel Estrzulas',
        'Florianopolis',
        'Santa Catarina',
        -27.5949884,
        -48.54817430000003,        
        'A'
    ],
    [
        15,
        'generic.png',
        'Álvaro Santos',
        'Vitória da Conquista',
        'Bahia',
        -14.86431985538257,
        -40.842977099999985,
        'A'
    ],
    [
        16,
        'generic.png',
        'David Rodrigues',
        'Porto Alegre',
        'Rio Grande do Sul',
        -30.0346471,
        -51.217658400000005,
        'A'
    ],
    [
        17,
        'generic.png',
        'Antonio Lima',
        'Cedro',
        'Ceará',
        -6.7943548,
        -39.298210299999994,
        'A'
    ],
    [
        18,
        'generic.png',
        'Patricia Mascare',
        'Montes Claros',
        'Minas Gerais',
        -16.7286406,
        -43.85821390000001,
        'A'
    ],
    [
        19,
        'generic.png',
        'Pablo Souza',
        'Ouro Branco',
        'Minas Gerais',
        -20.5236387,
        -43.691412000000014,
        'A'
    ],
    [
        20,
        'generic.png',
        'Andre Simonelli',
        'São Bernardo',
        'São Paulo',
        -23.6898429,
        -46.564848100000006,
        'A'
    ],
    [
        21,
        'generic.png',
        'Jessica Viana',
        'Macapá',
        'Amapá',
        0.0355735,
        -51.07053500000001,
        'A'
    ],
    [
        22,
        'generic.png',
        'Erik Guimarães',
        'Porto Velho',
        'Rondônia',
        -8.761160499999999,
        -63.90043029999998,
        'A'
    ],
    [
        23,
        'generic.png',
        'Cedric Filho',
        'Boa Vista',
        'Roraima',
        2.8235098,
        -60.67583309999998,
        'A'
    ],
    [
        24,
        'generic.png',
        'Sandro Gomes',
        'Belém',
        'Pará',
        -1.4557794,
        -48.490196800000035,
        'A'
    ],
    [
        25,
        'generic.png',
        'Gabriel Pinho',
        'Itaituba',
        'Pará',
        -4.2670701,
        -55.993117299999994,
        'A'
    ],
    [
        26,
        'generic.png',
        'Thiago Monteiro',
        'Teresina',
        'Piauí',
        -5.0920108,
        -42.8037597,
        'A'
    ],

     [
        27,
        'generic.png',
        'Juliana Silva',
        'Barbacena',
        'Minas Gerais',
        -21.219787245385913,
         -43.769088150000016,
        'A'
    ],
        [
        28,
        'generic.png',
        'Rodrigo Barbosa',
        'Belo Horizonte',
        'Minas Gerais',
        -19.90276677995094,
        -43.96405015000005,
        'A'
    ],
    [
        29,
        'generic.png',
        'Douglas Moreira',
        'Itaúna',
        'Minas Gerais',
        -20.08437091074378,
        -44.58390005000001,
        'A'
    ],
   [
        30,
       'generic.png',
        'Dênis Silva',
       'Capanema',
       'Pará',
       -1.1871893858193552,
       -47.16989604999998,
       'A'
    ],
    [
        31,
        'generic.png',
        'Paulo Rezende',
        'Poço Fundo',
        'Minas Gerais',
        -21.780487624359065,
        -45.96618539999997,
        'A'
    ],
    [
        32,
        'generic.png',
        'Antonio Lima',
        'Independência',
        'Ceará',
        -5.401613727823183,
        -40.27896288281248,
        'A'
    ],
    [
        33,
        'generic.png',
        'Jose Sousa',
        'Itaquaquecetuba',
        'São Paulo',
        -23.463668998872894,
        -46.33200160000001,
        'A'
    ],
    [
        34,
        'generic.png',
        'Daniel Araújo',
        'Governador Valadares',
        'Minas Gerais',
        -18.894850160631204,
        -41.976762125976556,
        'A'
    ],
    [
        35,
        'generic.png',
        'Janaina Oliveira',
        'Cataguases',
        'Minas Gerais',
        -21.401389450615632,
        -42.684548726953146,
        'A'
    ],                  
    [
        36,
        'generic.png',
        'David Rodrigues',
        'Porto Alegre',
        'Rio Grande do Sul',
        -30.108987424667596,
        -51.17690455000002,
        'A'
    ],  
    [
        37,
        'generic.png',
        'Thiago Costa',
        'Barbacena',
        'Minas Gerais',
        -21.21658675989109,
        -43.770461441015655,
        'A'
    ],  
    [
        38,
        'generic.png',
        'Diego Feitosa',
        'São Cristóvão',
        'Sergipe',
        -11.00887930365787,
        -37.20469809999997,
        'A'
    ],  
    [
        39,
        'generic.png',
        'Edésio Souza',
        'Cataguases',
        'Minas Gerais',
        -21.39243898762419,
        -42.68592201796877,
        'A'
    ], 
    [
        40,
        'generic.png',
        'Bruno Foletto',
        'Santa Maria',
        'Rio Grande do Sul',
        -29.702720446694684,
        -53.76274964999999,
        'A'
    ], 
    [
        41,
        'generic.png',
        'William Braz',
        'São Paulo',
        'São Paulo',
        -23.591608254157368,
        -46.56440015214843,
        'A'
    ], 
    [
        42,
        'generic.png',
        'José Filho',
        'Ananideua',
        'Pará',
        -1.3598306032155727,
        -48.38917594999998,
        'A'
    ], 
    [
        43,
        'generic.png',
        'Paulo Brito',
        'Montes Claros',
        'Minas Gerais',
        -16.72810256579216,
        -43.85108285000001,
        'A'
    ], 
    [
        44,
        'generic.png',
        'Rafael Cunha',
        'Barbacena',
        'Minas Gerais',
        -21.22001727760663,
        -43.77483880612796,
        'A'
    ], 
    [
        45,
        'generic.png',
        'William Junior',
        'Muriaé',
        'Minas Gerais',
        -21.130456315331074,
        -42.369706699999995,
        'A'
    ],       
    [
        46,
        'generic.png',
        'Klaisler Santos',
        'Belo Horizonte',
        'Minas Gerais',
        -19.90276677995094,
        -43.987996912085,
        'A'
    ],  
    [
        47,
        'generic.png',
        'Bráulio Barbosa',
        'Timóteo',
        'Minas Gerais',
        -19.557764345811766,
        -42.63432295000001,
        'A'
    ],
    [
        48,
        'generic.png',
        'Adriano Borges',
        'Coromandel',
        'Minas Gerais',
        -18.47480701618551,
        -47.196530882031254,
        'A'
    ],
    [
        49,
        'generic.png',
        "Marcelo José",
        'São Paulo',
        'São Paulo',
        -23.592866761333386,
        -46.4802860774414,
        'A'
    ],    
    [
        50,
        'generic.png',
        "Edson Figueiredo",
        'Rio de Janeiro',
        'Rio de Janeiro',
        -22.911373304649324,
        -43.44844784999998,
        'A'
    ],
    [
        51,
        'generic.png',
        "Pablo Faria",
        'Formiga',
        'Minas Gerais',
        -20.462299405855806,
        -45.4272201,
        'A'
    ],
    [   
        52,
        'generic.png',
        "Edson Figueiredo",
        'Belo Horizonte',
        'Minas Gerais',
        -19.902988716252942,
        -43.96982226380009,
        'A'
    ],
    [   
        53,
        'generic.png',
        "Rafael Porto",
        'Belo Horizonte',
        'Minas Gerais',
        -19.901959736228623,
        -43.97164616593022,
        'A'
    ],    
    [   
        54,
        'generic.png',
        "Elizangela Silva",
        'Campo Grande',
        'Mato Grosso do Sul',
        -20.481139370806428,
        -54.63553405000005,
        'A'
    ],
    [   
        55,
        'generic.png',
        "Sidnei Cerqueira",
        'São Paulo',
        'São Paulo',
        -23.565176815450016,
        -46.59890408891601,
        'A'
    ],
    [   
        56,
        'generic.png',
        "Bergson Fernandes",
        'São Luís',
        'Maranhão',
        -2.5464870197601592,
        -44.26327184130861,
        'A'
    ],
    [   
        57,
        'generic.png',
        "Vitor Ferreira",
        'Belo Horizonte',
        'Minas Gerais',
        -19.901071983380568,
        -43.91235861786503,
        'A'
    ],    
    [   
        58,
        'generic.png',
        "Fernando Campos",
        'Entre Rio de Minas',
        'Minas Gerais',
        -20.671114808837157,
        -44.06580820000005,
        'A'
    ],
    [   
        59,
        'generic.png',
        "Daniella Paulino",
        'Belo Horizonte',
        'Minas Gerais',
        -19.900224578289755,
        -43.91012701996464,
        'A'
    ],  
    [   
        60,
        'generic.png',
        "Francisco Neto",
        'Belo Horizonte',
        'Minas Gerais',
        -19.907366850574274,
        -43.90982661255497,
        'A'
    ],  
    [   
        61,
        'generic.png',
        "Lucas Masi",
        'Belo Horizonte',
        'Minas Gerais',
        -19.901798326989486,
        -43.91931090363163,
        'A'
    ], 
    [   
        62,
        'generic.png',
        "Alysson Barros",
        'Belo Horizonte',
        'Minas Gerais',
        -19.912814129659207,
        -43.929224348150676,
        'A'
    ],     
    [   
        63,
        'generic.png',
        "Cássio Borges",
        'Araxá',
        'Minas Gerais',
        -19.595508997282373,
        -46.938718093655446,
        'A'
    ],
    [   
        64,
        'generic.png',
        "Tiago Lima",
        'Belo Horizonte',
        'Minas Gerais',
        -19.940249422976585,
        -43.94776377686161,
        'A'
    ],
    [   
        65,
        'generic.png',
        "Roberta Silva",
        'Uberaba',
        'Minas Gerais',
        -19.750986688451224,
        -47.93496225000001,
        'A'
    ],
    [   
        66,
        'generic.png',
        "Alessandro Paula",
        'Alvinópolis',
        'Minas Gerais',
        -20.112068640800658,
        -43.056639582031266,
        'A'
    ],
    [   
        67,
        'generic.png',
        "Erik Silva",
        'Porto Velho',
        'Rondônia',
        -8.777079069568785,
        -63.87009888186038,
        'A'
    ],
    [   
        68,
        'generic.png',
        "Hermano Conceicao",
        'São Luís',
        'Maranhão',
        -2.5860152843225537,
        -44.21675160815431,
        'A'
    ],
    [   
        69,
        'generic.png',
        "Érik Ramos",
        'São Carlos',
        'São Paulo',
        -22.0087175274814,
        -47.8909142,
        'A'
    ],
    [   
        70,
        'generic.png',
        "André Zerbinato",
        'São Bernardo',
        'São Paulo',
        -23.71167243927797,
        -46.54772934458009,
        'A'
    ],
    [   
        71,
        'generic.png',
        "João Martinez",
        'Cachoeiro de Itapemirim',
        'Espírito Santo',
        -20.852142108876222,
        -41.13997284999999,
        'A'
    ],
    [   
        72,
        'generic.png',
        "João Silva",
        'Alfenas',
        'Minas Gerais',
        -21.41797282335636,
        -45.95710082135008,
        'A'
    ],
    [   
        73,
        'generic.png',
        "Gustavo Friedrich",
        'Porto Alegre',
        'Rio Grande do Sul',
        -30.069627201770533,
        -51.18909250776368,
        'A'
    ],
    [   
        74,
        'generic.png',
        "Hemerson Lima",
        'Crateús',
        'Ceará',
        -5.17828488761217,
        -40.67353589999999,
        'A'
    ],
    [   
        75,
        'generic.png',
        "Matheus Melo",
        'Teófilo Otoni',
        'Minas Gerais',
        -17.86417021386693,
        -41.50428654819337,
        'A'
    ],    
    [   
        76,
        'generic.png',
        "Thais Pereira",
        'Montes Claros',
        'Minas Gerais',
        -16.730013670333935,
        -43.85498814632569,
        'A'
    ],
    [
        77,
        'generic.png',
        'Enrico Nicoletto',
        'Limeira',
        'São Paulo',
        -22.580945077893315,
        -47.41182879999997,
        'A'
    ],
    [
        1,
        'marciliogomes.png',
        'Marcílio Gomes', 
        'Belo Horizonte',
        'Minas Gerais',
        -19.96330971840028,
        -44.04805430039062,
        'P'
    ],
    [
        2,
        'marcosandrekutova.png',
        'Marcos A. Kutova',
        'Belo Horizonte',
        'Minas Gerais',
        -19.899564989656078,
        -43.99174936874999,
        'P'
    ],
    [
        3,
        'generic.png',
        'Marco R. Costa', 
        'Belo Horizonte',
        'Minas Gerais',
        -19.929907460018427,
        -43.973209940039055,
        'P'
    ]
]